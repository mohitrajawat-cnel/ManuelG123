<?php



if (!defined('_PS_VERSION_')) {

    exit;

}



class prestapros_apiconnector extends Module

{

    public function __construct()

    {

        $this->name = 'prestapros_apiconnector';

        $this->tab = 'front_office_features';

        $this->version = '1.0.0';

        $this->author = 'hirewordpressexperts.com';

        $this->need_instance = 0;

        $this->ps_versions_compliancy = [

            'min' => '1.7',

            'max' => _PS_VERSION_

        ];

        $this->bootstrap = true;



        parent::__construct();



        $this->displayName = $this->l('Prestashop API Connector');

        $this->description = $this->l('It will show all details of products in json format.');



        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

    }

	

	public function install()

    {

        if (!parent::install() || !$this->registerHook('displayHome') || !$this->registerHook('displayHeader') || !$this->registerHook('cart') || !$this->registerHook('actionCartSave')) 
        {
            return false;
        }

	

        return true;

    } 

   

    public function uninstall()

    {

        return parent::uninstall();

    }
   

	public function hookDisplayHeader($params)
	{
		
	}


	public function hookCart($params) {

		
				$cart = $params['cart'];
				$cart_id = $cart->id;

				$customer_id=$cart->id_customer;

			

				//print_r($cart);
				// die("gsdgsd");

	
	}

	public function  hookActionCartSave($params) {

		
		$cart = $params['cart'];
		$cart_id = $cart->id;

		$customer_id=$cart->id_customer;

	

		print_r($cart);
		// die("gsdgsd");


}

		


	public function getContent()

	{

			$output = null;

			

			

			

				 if (Tools::isSubmit('submit'.$this->name))

					 {

							$myModuleName = Tools::getValue("hweprestakey");

							$myModuleName_url = Tools::getValue("hweprestaurl");



							if (!$myModuleName ||empty($myModuleName) ) 

							{

								$output .= $this->displayError($this->l('Invalid Configuration value'));

							} else {

								Configuration::updateValue('hweprestakey', $myModuleName);

								$output .= $this->displayConfirmation($this->l('Settings updated'));

							}

							
							if (!$myModuleName_url ||empty($myModuleName_url) ) 

							{

								$output .= $this->displayError($this->l('Invalid Configuration value'));

							} else {

								Configuration::updateValue('hweprestaurl', $myModuleName_url);

								$output .= $this->displayConfirmation($this->l('Settings updated'));

							}

					}

					



			return $output.$this->displayForm();

		

	}

		public function displayForm()

			{

				// Get default language

				$defaultLang = (int)Configuration::get('PS_LANG_DEFAULT');



				// Init Fields form array

				$fieldsForm[0]['form'] = [

					'legend' => [

						'title' => $this->l('Settings'),

					],

					'input' => [

						[

							'type' => 'text',

							'label' => $this->l('Prestashop API KEY'),

							'name' => 'hweprestakey',

							'size' => 20,

							'required' => true

						]

					],

					'submit' => [

						'title' => $this->l('Save'),

						'class' => 'btn btn-default pull-right'

					]

				];

				$fieldsForm[1]['form'] = [

					'legend' => [

						'title' => $this->l('Settings'),

					],

					
					'input' => [

						[

							'type' => 'text',

							'label' => $this->l('Prestashop API URL'),

							'name' => 'hweprestaurl',

							'size' => 20,

							'required' => true

						]

					],

					'submit' => [

						'title' => $this->l('Save'),

						'class' => 'btn btn-default pull-right'

					]

				];



				$helper = new HelperForm();



				// Module, token and currentIndex

				$helper->module = $this;

				$helper->name_controller = $this->name;

				$helper->token = Tools::getAdminTokenLite('AdminModules');

				$helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;



				// Language

				$helper->default_form_language = $defaultLang;

				$helper->allow_employee_form_lang = $defaultLang;



				// Title and toolbar

				$helper->title = $this->displayName;

				$helper->show_toolbar = true;        // false -> remove toolbar

				$helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.

				$helper->submit_action = 'submit'.$this->name;

				$helper->toolbar_btn = [

					'save' => [

						'desc' => $this->l('Save'),

						'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.

						'&token='.Tools::getAdminTokenLite('AdminModules'),

					],

					'back' => [

						'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),

						'desc' => $this->l('Back to list')

					]

				];



				// Load current value

				$helper->fields_value['hweprestakey'] = Tools::getValue('hweprestakey', Configuration::get('hweprestakey'));
				$helper->fields_value['hweprestaurl'] = Tools::getValue('hweprestaurl', Configuration::get('hweprestaurl'));



				return $helper->generateForm($fieldsForm);

			}

	  

}